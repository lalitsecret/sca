import React from 'react'
import '../styles/footer.scss'
function App()
{
	return <footer>
		footer copy rights &copy;
	</footer>
}
export default App