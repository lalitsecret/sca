import React from 'react'
import '../styles/login.scss'
function App()
{
	return <div className="login">
		<div className="left">
			<h1>Signup</h1>
			<h3>We do not share your personal details with anyone</h3>
		</div>
		<div className="right">
			<p>First Name</p>
			<input placeholder="First Name"/>
			<p>Last Name</p>
			<input placeholder="Last Name"/>
			<p>Email</p>
			<input placeholder="Email"/>
			<p>Password</p>
			<input placeholder="Password"/>
			<p>Confirm Password</p>
			<input placeholder="Confirm Password"/>
			<button>Signup</button>
		</div>
	</div>
}
export default App