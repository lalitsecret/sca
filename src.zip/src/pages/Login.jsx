import React from 'react'
import '../styles/login.scss'
function App()
{
	return <div className="login">
		<div className="left">
			<h1>Login</h1>
			<h3>Get Acces to your orders wishlist and recommendations</h3>
		</div>
		<div className="right">
			<p>Email</p>
			<input placeholder="Email" />
			<p>Password</p>
			<input placeholder="password" />
			<button>Login</button>
		</div>
	</div>
}
export default App