import banners from './banner'
import categories from './categories'
import products from './products'

let data={
	products,
	categories,
	banners
}

export default data