import banners from './banner'
import categories from './categories'
import products from './products'
import users from './users'

let data={
	products,
	categories,
	banners,
	users
}

export default data