module.exports=[
	{id:1,name:"demo1",email:"demo1@gmail.com",password:"demo1"},
	{id:2,name:"demo2",email:"demo2@gmail.com",password:"demo2"},
	{id:3,name:"demo3",email:"demo3@gmail.com",password:"demo3"},
	{id:4,name:"demo4",email:"demo4@gmail.com",password:"demo4"},
	{id:5,name:"demo5",email:"demo5@gmail.com",password:"demo5"},
	{id:6,name:"demo6",email:"demo6@gmail.com",password:"demo6"},
]